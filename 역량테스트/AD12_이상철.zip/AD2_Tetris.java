import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

public class AD2_Tetris {
    private static int n, aCnt, bCnt;
    private static int[][] area;

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tcase = Integer.parseInt(br.readLine());

        for (int t = 1; t <= tcase; t++) {
            aCnt = 0;
            bCnt = 0;
            n = Integer.parseInt(br.readLine());
            area = new int[n + 1][6];
            String[] cmd = br.readLine().split(" ");
            for (int i = 0; i <= n; i++) for (int j = 0; j < 6; j++) area[i][j] = -1;
            for (int i = 0; i < n; i++) go(Integer.parseInt(cmd[i]), i % 2);
            System.out.println(Math.abs(aCnt - bCnt));
        }
    }

    private static void go(int cur, int color) {
        int lr = getLastRow(cur);
        area[lr][cur] = color;
        while (isBoom(color)) down();
    }

    private static boolean isBoom(int color) {
        boolean flag = false;
        for (int i = 0; i <= n; i++) {
            int cnt = 3;
            int colorFlag = 0;
            int[] chkList = new int[6];

            for (int j = 0; j < 3; j++) {
                if (area[i][j] != -1 && area[i][j] == area[i][j + 1] && area[i][j + 1] == area[i][j + 2] && area[i][j + 2] == area[i][j + 3]) {
                    if (area[i][j] == color && area[i][j] != -1) {
                        cnt++;
                        colorFlag = 1;
                    }
                    chkList[j] = 1;
                    chkList[j + 1] = 1;
                    chkList[j + 2] = 1;
                    chkList[j + 3] = 1;
                    flag = true;
                }
            }
            if (flag) {
                for (int j = 0; j < 6; j++) if (chkList[j] == 1) area[i][j] = -1;
                if (color == 0 && colorFlag == 1) aCnt += cnt;
                else if(color == 1 && colorFlag == 1) bCnt += cnt;
            }
        }
        return flag;
    }

    private static void down() {
        for (int i = 0; i < 6; i++) {
            LinkedList<Integer> list = new LinkedList<>();
            int j;
            for (j = 0; j <= n; j++) if (area[j][i] != -1) list.add(area[j][i]);
            for (j = list.size(); j <= n; j++) list.add(-1);
            for (j = 0; j <= n; j++) area[j][i] = list.pollFirst();
        }
    }

    private static int getLastRow(int cur) {
        for (int i = 0; i <= n; i++) if (area[i][cur] == -1) return i;
        return 0;
    }
}
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class AD1_Bus {
    private static int n;
    private static int[] dr = {0, 1, 1};
    private static int[] dc = {1, 0, 1};
    private static int[][] area;

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tcase = Integer.parseInt(br.readLine());
        for (int t = 1; t <= tcase; t++) {
            n = Integer.parseInt(br.readLine());
            area = new int[n][n];
            for (int i = 0; i < n; i++) {
                String[] tmp = br.readLine().split(" ");
                for (int j = 0; j < n; j++) area[i][j] = Integer.parseInt(tmp[j]);
            }
            System.out.println(bfs());
        }
    }

    private static int bfs() {
        int ret = 0;
        Queue<Node> queue = new LinkedList<>();
        if (area[0][0] == 1) return ret;
        if (area[0][1] == 0) queue.offer(new Node(0, 1, 0, 0, 0));
        if (area[1][0] == 0) queue.offer(new Node(1, 0, 0, 0, 1));

        while (!queue.isEmpty()) {
            int r = queue.peek().r;
            int c = queue.peek().c;
            int pr = queue.peek().pr;
            int pc = queue.peek().pc;
            int d = queue.peek().d;
            queue.poll();

            if (r == n - 1 && c == n - 1 && ((pr == n - 2 && pc == n - 1) || (pr == n - 1 && pc == n - 2))) {
                ret++;
                continue;
            }
            int nr, nc;
            if (d == 0 || d == 2) {
                nr = r + dr[0];
                nc = c + dc[0];
                if (nr >= 0 && nc >= 0 && nr < n && nc < n && area[nr][nc] == 0) queue.offer(new Node(nr, nc, r, c, 0));
            }
            if (d == 1 || d == 2) {
                nr = r + dr[1];
                nc = c + dc[1];
                if (nr >= 0 && nc >= 0 && nr < n && nc < n && area[nr][nc] == 0) queue.offer(new Node(nr, nc, r, c, 1));
            }
            boolean flag = true;
            for (int i = 0; i < 3; i++) {
                nr = r + dr[i];
                nc = c + dc[i];
                if (nr < 0 || nc < 0 || nr >= n || nc >= n || area[nr][nc] == 1) {
                    flag = false;
                    break;
                }
            }
            if (flag) queue.offer(new Node(r + 1, c + 1, r, c, 2));
        }
        return ret;
    }

    private static class Node {
        int r, c, pr, pc, d;

        public Node(int r, int c, int pr, int pc, int d) {
            this.r = r;
            this.c = c;
            this.pr = pr;
            this.pc = pc;
            this.d = d;
        }
    }
}
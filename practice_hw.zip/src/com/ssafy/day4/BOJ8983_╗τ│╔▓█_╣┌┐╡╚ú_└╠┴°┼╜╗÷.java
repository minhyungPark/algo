package com.ssafy.day4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BOJ8983_��ɲ�_�ڿ�ȣ_����Ž�� {
	static int M, N, L;
	static int[] sade;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		M = Integer.parseInt(st.nextToken());
		N = Integer.parseInt(st.nextToken());
		L = Integer.parseInt(st.nextToken());
		sade = new int[M];
		st = new StringTokenizer(br.readLine());
		for(int i = 0; i < M; i++) {
			sade[i] = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(sade);
		int x, y;
		
		int cnt = 0;
		int left, right, min, mid;
		for(int i = 0; i < N; i++) {
			st = new StringTokenizer(br.readLine());
			x = Integer.parseInt(st.nextToken());
			y = Integer.parseInt(st.nextToken());
			if(y > L) {
				continue;
			}
			left = 0;
			right = M - 1;
			min = Integer.MAX_VALUE;
			while(left <= right) {
				mid = (left + right) / 2;
				if(min > Math.abs(sade[mid] - x)) {
					min = Math.abs(sade[mid] - x);
					if(min <= L - y) {
						cnt++;
						break;
					}
				}
				
				if(sade[mid] < x) {
					left = mid + 1;
				}else {
					right = mid - 1;
				}
			}
		}
		
		System.out.println(cnt);
	}

}

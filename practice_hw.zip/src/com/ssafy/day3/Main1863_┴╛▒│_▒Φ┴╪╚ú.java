package com.ssafy.day3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main1863_����_����ȣ {

	private static ArrayList<Integer>[] list = null;
	private static Queue<Integer> q = new LinkedList<>();
	private static boolean[] visit;
	private static int[] check;

	public static void BFS(int index, int count) {
		if (!visit[index]) {
			q.add(index);
			visit[index] = true;
			check[index] = count;
		}

		while (!q.isEmpty()) {
			int indexQ = q.poll();
			for (int temp : list[indexQ]) {
				if (!visit[temp]) {
					q.add(temp);
					visit[temp] = true;
					check[temp] = count;
				}
			}

		}

	}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int size = input.nextInt();
		int nodeNum = input.nextInt();

		check = new int[size + 1];
		list = new ArrayList[size + 1];
		visit = new boolean[size + 1];
		for (int i = 0; i <= size; i++) {
			list[i] = new ArrayList<Integer>();
		}
		for (int i = 0; i < nodeNum; i++) {
			int temp1 = input.nextInt();
			int temp2 = input.nextInt();
			list[temp1].add(temp2);
			list[temp2].add(temp1);
		}

//		for (int i = 1; i <= size; i++) {
//			Collections.sort(list[i]);
//		}
		int count = 0;
		for (int i = 1; i <= size; i++) {
			q.clear();
			if(!visit[i]) {
				count++;
			}
			BFS(i, count);
		}
		int max = 0;
		for (int result : check) {
			max = Math.max(result, max);
		}
		System.out.println(max);
	}

}

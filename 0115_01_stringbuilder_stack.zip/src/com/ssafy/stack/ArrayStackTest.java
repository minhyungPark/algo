package com.ssafy.stack;

import java.util.Stack;

class ArrayStack2 {

	private String stack[];
	private int top = -1, size;
	
	public ArrayStack2(int size) {
		stack = new String[size];
		this.size = size;
	}
	
	public void push(String element) {
		if(top == size-1) {
			System.out.println("������ ��ȭ�����Դϴ�.");
			return;
		}
		stack[++top] = element;
	}
	public String pop() {
		String element = peek();
		if(element !=null) {
			stack[top--] = null;
		}
		return element;
	}
	
	public String peek() {
		if(isEmpty()) {
			System.out.println("������ ����־� �Ұ����մϴ�.");
			return null;
		}
		return stack[top];
	}
	
	public boolean isEmpty() {
		return top==-1;
	}
	public int size() {
		return top+1;
	}
}




public class ArrayStackTest {

	public static void main(String[] args) {

//		ArrayStack stack = new ArrayStack(5);
		ArrayStack2 stack = new ArrayStack2(5);
//		Stack stack = new Stack();
		stack.push("����ȯ");
		stack.push("���ٴϿ�");
		stack.push("Ȳ����");
		stack.push("������");
		stack.push("�����");
//		stack.push("ȫ�浿");
		
		System.out.println("========================");
		System.out.println(stack.size());
		System.out.println(stack.peek());
		System.out.println(stack.size());
		System.out.println(stack.pop());
		System.out.println(stack.size());
		System.out.println(stack.pop());
		System.out.println(stack.pop());
		System.out.println(stack.pop());
		System.out.println(stack.pop());
		System.out.println(stack.pop());
		
	}

}










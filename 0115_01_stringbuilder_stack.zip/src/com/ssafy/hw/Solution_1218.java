package com.ssafy.hw;

import java.util.Scanner;
public class Solution_1218 {
 
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
         
        int tCase = 10;
        int a = 0; //{
        int b = 0; //[
        int c = 0; //(
        int d = 0; //<
        int num;
        int flag;
        char arry[];
        String str;
        for(int i=1;i<=tCase;i++) {
            num = sc.nextInt();
            arry = new char[num];
            str = sc.next();
            a = 0;
            b = 0;
            c = 0;
            d = 0;
            flag = 0;
             
             
            for(int j=0;j<num;j++) {
                arry[j] = str.charAt(j);
            }
             
            for(int j=0;j<num;j++) {
                if(arry[j]=='{') a++;
                else if(arry[j]=='[') b++;
                else if(arry[j]=='(') c++;
                else if(arry[j]=='<') d++;
                else if(arry[j]=='}') a--;
                else if(arry[j]==']') b--;
                else if(arry[j]==')') c--;
                else if(arry[j]=='>') d--;
            }
             
            if(a==0 && b==0 && c==0 && d==0) flag = 1;
            else flag = 0;
             
            System.out.println("#"+i+" "+flag);
        }
         
         
 
    }
 
}

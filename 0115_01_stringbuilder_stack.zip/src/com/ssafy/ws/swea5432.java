package com.ssafy.ws;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;

public class swea5432 {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String tmp = br.readLine();
        int tcase = Integer.parseInt(tmp);
        for(int t = 1; t <= tcase; t++) {
            int ans = 0;
            char[] str = br.readLine().toCharArray();
            Stack stack = new Stack();

            stack.push(str[0]);
            for(int i = 1; i < str.length;i++) {
                if(str[i] == '(') stack.push(str[i]);
                else {
                	stack.pop();
                    if(str[i-1] == '(' && str[i] == ')') {//������
                        ans += stack.size();
                    }else{ // �踷���
                        ans++;
                    }
                }

            }
            System.out.println("#" + t + " " + ans);
        }
    }
}

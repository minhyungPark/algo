package com.ssafy.tree;

public class BinaryTree {

	private Object[] nodes;
	private int lastIndex;
	private final int SIZE;
	private final int MAX_LEVEL;
	
	public BinaryTree(int size) {
		super();
		SIZE = size;
		nodes = new Object[SIZE+1]; // 0�ε��� ������
		
		int count = 0;
		for(int base=1; base<=SIZE; base<<=1,count++);
		MAX_LEVEL = count-1;
		
	}
	public boolean isEmpty() {
		return lastIndex == 0;
	}
	public boolean isFull() {
		return lastIndex == SIZE;
	}
	
	public void add(Object e) {
		if(isFull()) {
			System.out.println("��ȭ�����Դϴ�.");
			return;
		}
		nodes[++lastIndex] = e;
	}
	
	public void printTreeByLevelOrder() {
		int start, end;
		for(int i=0; i<=MAX_LEVEL; ++i) {
			start = (int)Math.pow(2, i);
			end = (int)Math.pow(2, i+1)-1;
			for(int j=start; j<=lastIndex && j<=end; ++j) {
				System.out.print(nodes[j]+"\t");
			}
			System.out.println();
		}
		System.out.println();
	}
	
	
	public void printTreeByPreOrder() {
		printTreeByPreOrder(1);
		System.out.println();
	}
	private void printTreeByPreOrder(int current) {//CLR
		if(current <= lastIndex) {
			System.out.print(nodes[current]+" ");
			printTreeByPreOrder(current*2); // Left
			printTreeByPreOrder(current*2+1); // Right
		}
	}
	public void printTreeByInOrder() {
		printTreeByInOrder(1);
		System.out.println();
	}
	private void printTreeByInOrder(int current) {//LCR
		if(current <= lastIndex) {
			printTreeByInOrder(current*2); // Left
			System.out.print(nodes[current]+" ");
			printTreeByInOrder(current*2+1); // Right
		}
	}
	public void printTreeByPostOrder() {	// LRC
		printTreeByPostOrder(1);
		System.out.println();
	}
	private void printTreeByPostOrder(int current) {//CLR
		if(current <= lastIndex) {
			printTreeByPostOrder(current*2); // Left
			printTreeByPostOrder(current*2+1); // Right
			System.out.print(nodes[current]+" ");
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

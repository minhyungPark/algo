package com.ssafy.tree;

import java.util.Stack;

public class ExpressionLinkedTree {
	private TreeNode root;

	// ����ǥ��� ����. 23+  2  3  +
	public void makeTree(String postExpression) {
		
		Stack<TreeNode> stack = new Stack<TreeNode>();
		int length = postExpression.length();
		char c;
		TreeNode node = null;
		for(int i=0; i<length; ++i) {
			c = postExpression.charAt(i);
			node = new TreeNode(c);
			switch(c) {
			case '+':case '-':case '*':case '/':
				node.right = stack.pop();
				node.left = stack.pop();
				break;
			}
			stack.push(node);
		}
		root = stack.pop();
	}
	
	
	public void printTreeByPreOrder() {
		printTreeByPreOrder(root);
		System.out.println();
	}
	private void printTreeByPreOrder(TreeNode node) {//CLR
		if(node != null) {
			System.out.print(node.data+" ");
			printTreeByPreOrder(node.left);
			printTreeByPreOrder(node.right);
		}
	}
	public void printTreeByInOrder() {
		printTreeByInOrder(root);
		System.out.println();
	}
	private void printTreeByInOrder(TreeNode node) {//LCR
		if(node != null) {
			printTreeByInOrder(node.left);
			System.out.print(node.data+" ");
			printTreeByInOrder(node.right);
		}
	}
	public void printTreeByPostOrder() {	// LRC
		printTreeByPostOrder(root);
		System.out.println();
	}
	private void printTreeByPostOrder(TreeNode node) {//CLR
		if(node != null) {
			printTreeByPostOrder(node.left);
			printTreeByPostOrder(node.right);
			System.out.print(node.data+" ");
		}
	}
	
		
	
	
	
}

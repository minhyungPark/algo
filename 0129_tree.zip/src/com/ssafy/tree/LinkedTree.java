package com.ssafy.tree;

public class LinkedTree {
	private TreeNode root;
	private int size;
	
	public void add(Object pData,Object data) {
		TreeNode pNode = getNode(root,pData);
		TreeNode newNode = new TreeNode(data);
		if(pNode == null && size==0) { // �θ� ��尡 ������ �θ��� �����ؼ� ��Ʈ�� �����ϰ� �ڽ����� add
			root = pNode = new TreeNode(pData);
			size++;
		}else if(pNode == null) {
			System.out.println("ã�� �θ��尡 �������� �ʾ� �߰��Ҽ� �����ϴ�.");
			return;
		}
				
		if(pNode.left == null) {
			pNode.left = newNode;
			size++;
		}else if(pNode.right == null) {
			pNode.right = newNode;
			size++;
		}
		
	}
	public TreeNode getNode(TreeNode node,Object data) {
		TreeNode temp ;
		if(node == null) return null;
		if(node.data.equals(data)) return node;
		temp = getNode(node.left, data);
		if(temp == null) temp = getNode(node.right, data);
		
		return temp;
	}
	public void printTreeByPreOrder() {
		printTreeByPreOrder(root);
		System.out.println();
	}
	private void printTreeByPreOrder(TreeNode node) {//CLR
		if(node != null) {
			System.out.print(node.data+" ");
			printTreeByPreOrder(node.left);
			printTreeByPreOrder(node.right);
		}
	}
	public void printTreeByInOrder() {
		printTreeByInOrder(root);
		System.out.println();
	}
	private void printTreeByInOrder(TreeNode node) {//LCR
		if(node != null) {
			printTreeByInOrder(node.left);
			System.out.print(node.data+" ");
			printTreeByInOrder(node.right);
		}
	}
	public void printTreeByPostOrder() {	// LRC
		printTreeByPostOrder(root);
		System.out.println();
	}
	private void printTreeByPostOrder(TreeNode node) {//CLR
		if(node != null) {
			printTreeByPostOrder(node.left);
			printTreeByPostOrder(node.right);
			System.out.print(node.data+" ");
		}
	}
	
		
	
	
	
}

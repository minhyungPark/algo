package com.ssafy.tree;

public class TreeNode {
	Object data;
	TreeNode left,right;
	public TreeNode() {
		super();
	}
	public TreeNode(Object data) {
		super();
		this.data = data;
	}
	public TreeNode(Object data, TreeNode left, TreeNode right) {
		super();
		this.data = data;
		this.left = left;
		this.right = right;
	}
	
	
}

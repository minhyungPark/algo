package com.ssafy.day4;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedList;
  
class Pair
{
    int row;
    int col;
  
    public Pair(int row, int col)
    {
        super();
        this.row = row;
        this.col = col;
    }
  
}
  
public class D4_1868_������������ã��_�����
{
    static int T, N,cnt;
    static char[][] a;
    static boolean[][] check;
    static int[][] dir = { { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, -1 }, { 0, 1 }, { 1, -1 }, { 1, 0 }, { 1, 1 } };
  
    public static void main(String[] args) throws Exception
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        T = Integer.parseInt(br.readLine());
  
        for (int tc = 1; tc <= T; tc++)
        {
            N = Integer.parseInt(br.readLine());
            a = new char[N][N];
            check = new boolean[N][N];
            cnt=0;
            for (int i = 0; i < N; i++)
            {
                String temp = br.readLine();
                for (int j = 0; j < N; j++)
                {
                    a[i][j] = temp.charAt(j);
                }
            }
            LinkedList<Pair> q = new LinkedList<Pair>();
              
              
            for(int i=0;i<N;i++)
            {
                for(int j=0;j<N;j++)
                {
                    if(a[i][j]=='.' && !check[i][j] && directionCheck(i,j))
                    {
                        q.push(new Pair(i,j));
                        check[i][j]=true;
                        cnt++;
                        bfs(q);
                          
                    }
                }
            }
            for(int i=0;i<N;i++)
            {
                for(int j=0;j<N;j++)
                {
                    if(a[i][j]=='.' && !check[i][j])cnt++;
                      
                }
            }
            System.out.println("#"+tc+" "+cnt);
              
              
        }
    }
  
    public static boolean directionCheck(int row, int col)
    {
        for (int i = 0; i < 8; i++)
        {
            int r = row + dir[i][0];
            int c = col + dir[i][1];
            if (r < 0 || c < 0 || r >= N || c >= N) continue;
            if (a[r][c] == '*') return false;
        }
        return true;
  
    }
  
    public static void bfs(LinkedList<Pair> q)
    {
  
        while (!q.isEmpty())
        {
            Pair first = q.pollFirst();
  
            for (int i = 0; i < 8; i++)
            {
                int r = first.row + dir[i][0];
                int c = first.col + dir[i][1];
  
                if (r < 0 || c < 0 || r >= N || c >= N || check[r][c]) continue;
                if (directionCheck(r, c))
                {
                    check[r][c] = true;
                    q.push(new Pair(r, c));
                }
                else check[r][c] = true;
  
            }
  
        }
  
    }
  
}

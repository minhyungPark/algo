package com.ssafy.day4;

import java.io.IOException;
import java.util.Scanner;

public class Solution_D4_1868_������������ã��_������ {

	static int  N;
	static int[][] direction = { {-1,0},{1,0},{0,-1},{0,1},{-1,-1},{-1,1},{1,-1},{1,1}};
	static int[][] map;
	public static void main(String[] args) throws NumberFormatException, IOException {

		Scanner in = new Scanner(System.in);
		int T = in.nextInt();
			
		for(int t=1; t<=T; ++t) {
			N = in.nextInt();
			map = new int[N][N];

			for(int i=0;i<N;++i) {
				char ch[] = in.next().toCharArray();
				for(int j=0; j<N;++j) {
					if(ch[j]=='*') map[i][j] = -1;
				}
			}
			int count=0;
			for(int i=0;i<N;++i) {
				for(int j=0; j<N;++j) {
					if(map[i][j]==0 && isClean(i, j)) { // ���ڸ��� 8�濡 ���ڰ� ������ �ֺ� ó��
                        map[i][j] = ++count;
						process(i,j,count);
					}
				}
			}
			
			for(int i=0;i<N;++i) {
				for(int j=0; j<N;++j) {
					if(map[i][j]==0) count++;
				}
			}
			System.out.println("#"+t+" "+count);
		}
		in.close();
	}
	private static void process(int x, int y,int count) {
		if(isClean(x, y)) {		
			int newX,newY;
			for(int d=0; d<direction.length;++d) {
				newX = x+direction[d][0];
				newY = y+direction[d][1];
				if(newX>=0 && newX<N && newY>=0 && newY<N && map[newX][newY] == 0) {
					map[newX][newY] = count;
					process(newX,newY,count);
				}
			}
		}
	}
	private static boolean isClean(int x, int y) {
		int newX,newY;
		for(int d=0; d<direction.length;++d) {
			newX = x+direction[d][0];
			newY = y+direction[d][1];
			if(newX>=0 && newX<N && newY>=0 && newY<N && map[newX][newY]==-1) return false;
		}
		return true;
	}
}
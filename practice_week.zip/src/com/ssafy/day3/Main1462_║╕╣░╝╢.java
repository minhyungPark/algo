package com.ssafy.day3;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main1462_������ {	// ���� 1462 ������
	/*
	 * W �ٴ� 0
	 * L ���� 1
	 */
	static int max=0;
	static int n;
	static int m;
	static int[] dx= {0,0,-1,1};
	static int[] dy= {-1,1,0,0};
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		m=sc.nextInt();
		int[][] arr=new int[n][m];
		for(int i=0;i<n;i++) {
			String str=sc.next();
			for(int j=0;j<m;j++) {
				char c=str.charAt(j);
				if(c=='W') arr[i][j]=0;
				else if(c=='L') arr[i][j]=1;
			}
		}
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				if(arr[i][j]==0) continue;
				bfs(arr,i,j);
			}
		}
		System.out.println(max);
	}
	public static void bfs(int[][] arr,int startY, int startX) {
		boolean[][] visit=new boolean[n][m];
		Queue<int[]> q=new LinkedList<>();
		int[] start= {startY,startX,0};
		visit[startY][startX]=true;
		q.add(start);
		while(!q.isEmpty()) {
			int[] temp=q.remove();
			int y=temp[0];
			int x=temp[1];
			int length=temp[2];
			max=max>length?max:length;
			for(int d=0;d<4;d++) {
				int ty=y+dy[d];
				int tx=x+dx[d];
				if(ty<0||ty>=n||tx<0||tx>=m) continue;
				if(arr[ty][tx]==0) continue;
				if(visit[ty][tx]) continue;
				visit[ty][tx]=true;
				int[] next= {ty,tx,length+1};
				q.add(next);
			}
		}
	}
}

package com.ssafy.day3;
import java.util.Scanner;

public class Solution_D3_6485_�Ｚ���ǹ����뼱_������ {

	static int N,P;
	static int[][] line;
	static int[] bus;
	static int[] answer;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for(int tc=1; tc<=T; tc++) {
			N = sc.nextInt();
			
			line = new int[N][2];
			for(int i=0; i<N; i++) {
				line[i][0] = sc.nextInt();
				line[i][1] = sc.nextInt();
			}
			P = sc.nextInt();
			bus = new int[P];
			answer = new int[P];
			for(int i=0; i<P; i++) {
				bus[i] = sc.nextInt();
				for(int j=0; j<N; j++) {
					if(bus[i]>=line[j][0] && bus[i]<=line[j][1]) answer[i]++;
				}
			}
	
			System.out.print("#"+tc+" ");
			for(int i=0; i<P; i++) {
				System.out.print(answer[i]+" ");
			}
			System.out.println();
		}
	}
}

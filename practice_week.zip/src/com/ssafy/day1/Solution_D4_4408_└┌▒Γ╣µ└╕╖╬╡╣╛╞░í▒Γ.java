package com.ssafy.day1;
import java.util.Scanner;

public class Solution_D4_4408_�ڱ�����ε��ư��� {	// sw 4408
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int test=sc.nextInt();
		for(int t=1;t<=test;t++) {
			int n=sc.nextInt();
			int[][] arr=new int[n+1][2];
			int[] multiple=new int[401];
			int max=0;
			for(int i=1;i<=n;i++) {
				arr[i][0]=sc.nextInt();
				arr[i][1]=sc.nextInt();
			}
			for(int i=1;i<=n;i++) {
				int a=(arr[i][0]+1)>>1;
				int b=(arr[i][1]+1)>>1;
				int big=a>b?a:b;
				int small=a<b?a:b;
				for(int j=small;j<=big;j++) {
					multiple[j]++;
				}
			}
			for(int i=1;i<=400;i++) {
				max=max>multiple[i]?max:multiple[i];
			}
			System.out.println("#"+t+" "+max);
		}
	}
}

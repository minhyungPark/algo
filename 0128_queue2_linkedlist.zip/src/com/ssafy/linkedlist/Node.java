package com.ssafy.linkedlist;

public class Node {
	public Object data;
	public Node link;
	
	public Node(Object data, Node link) {
		super();
		this.data = data;
		this.link = link;
	}
	public Node(Object data) {
		super();
		this.data = data;
	}
	public Node() {
		super();
	}
	
}

package com.ssafy.linkedlist;

public class LinkedListTest {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.printList();
		list.addLastNode("����ȯ");
		list.printList();
		list.addLastNode("�����");
		list.printList();
		list.addFirstNode("������");
		list.printList();
		Node node = list.getNode("�����");
		list.insertAfterNode(node, "������");
		list.printList();
		list.insertAfterNode(node, "�ڰǿ�");
		list.printList();	
		
		list.deleteLastNode();
		list.printList();	
		list.deleteLastNode();
		list.printList();	
		list.deleteLastNode();
		list.printList();	
		list.deleteLastNode();
		list.printList();	
		list.deleteLastNode();
		list.printList();	
	}

}










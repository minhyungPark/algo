package com.ssafy.linkedlist;

public class LinkedList {

	private Node head;
	
	// ������ ��� ã��
	public Node getLastNode() {
		Node currNode = head;
		if(currNode != null) {
			while(currNode.link != null) {
				currNode = currNode.link;
			}
		}
		return currNode;
	}
	
	// Ư������� �ٷ� ������� ã��
	public Node getPreviousNode(Node node) {
		Node currNode = head, preNode = null,nextNode;
		if(currNode != null) {
			while(  (nextNode = currNode.link) != null ) {
				if(nextNode == node) {
					preNode = currNode;
					break;
				}
				currNode = nextNode;
			}
		}
		return preNode;
	}
	// ������ ���� �߰�
	public void addLastNode(Object data) {
		Node lastNode = getLastNode();
		Node newNode = new Node(data);
		
		if(lastNode == null) { // �󸮽�Ʈ
			head = newNode;
		}else {
			lastNode.link = newNode;
		}
	}
	// ù��° ���� �߰�
	public void addFirstNode(Object data) {
		Node newNode = new Node(data, head);
		head = newNode;
	}
	
	// ������ ��� �ڿ� �߰�
	public void insertAfterNode(Node preNode,Object data) {
		if(preNode != null) {
			Node newNode = new Node(data, preNode.link);
			preNode.link = newNode;
		}else {
			addFirstNode(data);
		}
	}
	public Node getNode(Object data) {
		Node currNode = head, node=null;
		while(currNode != null) {
			if(currNode.data.equals(data)) {
				node = currNode;
				break;
			}
			currNode = currNode.link;
		}
		return node;
	}
	public void deleteLastNode() {
		Node lastNode = getLastNode();
		if(lastNode == null) return;
		Node preNode = getPreviousNode(lastNode);
		if(preNode != null) { //������尡 �ִٸ�
			preNode.link = null;
		}else { // ������尡 ���ٸ� ��� 1��¥�� ����Ʈ
			head = null;
		}
	}
	
	public void printList() {
		Node currNode = head;
		System.out.print("LinkedList = [ ");
		while(currNode != null) {
			System.out.print(currNode.data+"\t");
			currNode = currNode.link;
		}
		System.out.println(" ]");
	}
}






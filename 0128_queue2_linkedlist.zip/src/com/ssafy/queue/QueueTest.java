package com.ssafy.queue;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
public class QueueTest {
	
	public static void main(String[] args) {
		
		CircularQueue queue = new CircularQueue(4);
		queue.enQueue("����ȯ");
		queue.enQueue("���ٴϿ�");
		queue.enQueue("Ȳ����");
		System.out.println(queue.deQueue());
		System.out.println(queue.deQueue());
		System.out.println(queue.deQueue());
		queue.enQueue("������");
		
		
		
		
	}

}












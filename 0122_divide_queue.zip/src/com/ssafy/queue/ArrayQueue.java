package com.ssafy.queue;

public class ArrayQueue {

	private Object[] queue;
	final int MAX_SIZE;
	private int front,rear;
	
	public ArrayQueue(int maxSize) {
		super();
		MAX_SIZE = maxSize;
		queue = new Object[MAX_SIZE];
		front=rear=-1;
	}
	
	public boolean isEmpty() {
		return front==rear;
	}
	public boolean isFull() {
		return rear == MAX_SIZE-1;
	}
	public void enQueue(Object item) {
		if(isFull()) {
			System.out.println("��ȭ�����̾  enqueue �Ұ�");
			return;
		}
		
		queue[++rear] = item;
	}
	public Object peek() {
		if(isEmpty()) {
			System.out.println("������¶� �Ұ� ");
			return null;
		}
		return queue[front+1];
	}
	public Object deQueue() {
		Object item = peek(); //  �Ǿ� ���� Ȯ��
		if(item != null) queue[++front] = null; // �Ǿտ��� ������ ó�� 
			
		return item;
	}
	
}















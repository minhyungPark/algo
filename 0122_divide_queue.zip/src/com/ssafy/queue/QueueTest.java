package com.ssafy.queue;

import java.util.LinkedList;
import java.util.Queue;

public class QueueTest {

	public static void main(String[] args) {

/*		ArrayQueue queue = new ArrayQueue(4);
		queue.enQueue("����ȯ");
		queue.enQueue("���ٴϿ�");
		queue.enQueue("Ȳ����");
		queue.enQueue("�ں���");
		queue.enQueue("������");
		System.out.println(queue.peek());
		System.out.println(queue.deQueue());
		System.out.println(queue.deQueue());
		System.out.println(queue.deQueue());
		System.out.println(queue.deQueue());
		System.out.println(queue.deQueue());*/
		
		Queue<String> queue2 = new LinkedList<String>();
		queue2.offer("����ȯ");
		queue2.offer("���ٴϿ�");
		queue2.offer("Ȳ����");
		queue2.offer("�ں���");
		queue2.offer("������");
		System.out.println(queue2.peek());
		System.out.println(queue2.poll());
		System.out.println(queue2.poll());
		System.out.println(queue2.poll());
		System.out.println(queue2.poll());
		System.out.println(queue2.poll());
		System.out.println(queue2.poll());
		System.out.println(queue2.remove());
		
		
		
		
	}

}












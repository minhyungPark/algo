package com.ssafy.recursive;

import java.util.Scanner;

public class Hanoi {

	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		
		
		
	}

}
